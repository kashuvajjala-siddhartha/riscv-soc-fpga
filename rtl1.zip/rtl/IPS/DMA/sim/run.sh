#!/usr/bin/env bash
# =============================================================================
# run.sh — DMA Stage 1 VCS Simulation Script
# Project : DMA IP — VeeR EL2 SoC Honours Project
# =============================================================================
# Note on error handling:
#   set -e is NOT used around the VCS compile+tee pipeline because tee always
#   returns 0 and 'set -e' with PIPESTATUS requires careful ordering.
#   Instead, VCS exit status is captured explicitly via PIPESTATUS[0].

set -uo pipefail

VCS_HOME=/home/student/snps_tools_target/vcs/U-2023.03
export VCS_HOME
export PATH=$VCS_HOME/linux64/bin:$VCS_HOME/bin:$PATH
export LD_LIBRARY_PATH=/usr/lib64:$VCS_HOME/linux64/lib:${LD_LIBRARY_PATH:-}
export LM_LICENSE_FILE=27020@cadence

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DMA_ROOT="$(dirname "$SCRIPT_DIR")"
RTL_DIR="$DMA_ROOT/rtl"
TB_DIR="$DMA_ROOT/tb"
WORK_DIR="$SCRIPT_DIR/work"

mkdir -p "$WORK_DIR"

TB_NAME="tb_dma_uart_to_mem"
SIMV="$WORK_DIR/simv_${TB_NAME}"
CLOG="$WORK_DIR/compile_${TB_NAME}.log"
SLOG="$WORK_DIR/sim_${TB_NAME}.log"

echo "============================================================"
echo "[INFO]  Compiling ${TB_NAME} ..."

# Disable pipefail temporarily so tee does not mask VCS exit code
set +o pipefail
"$VCS_HOME/bin/vcs" \
    -full64 -sverilog +v2k \
    -timescale=1ns/1ps \
    -debug_access+all \
    +warn=all \
    -top "${TB_NAME}" \
    -o "$SIMV" \
    -l "$CLOG" \
    "$RTL_DIR/dma_pkg.sv" \
    "$RTL_DIR/dma_fifo.sv" \
    "$RTL_DIR/dma_uart_to_mem.sv" \
    "$TB_DIR/${TB_NAME}.sv" \
    2>&1 | tee "$CLOG"
COMPILE_EXIT=${PIPESTATUS[0]}
set -o pipefail

if [ "$COMPILE_EXIT" -ne 0 ]; then
    echo "[FAIL]  Compilation failed (exit $COMPILE_EXIT) — see $CLOG"
    exit "$COMPILE_EXIT"
fi
echo "[INFO]  Compilation succeeded."

echo "[INFO]  Running ${TB_NAME} ..."
set +o pipefail
"$SIMV" -no_save 2>&1 | tee "$SLOG"
SIM_EXIT=${PIPESTATUS[0]}
set -o pipefail

echo "============================================================"
if [ "$SIM_EXIT" -eq 0 ] && grep -q "ALL TESTS PASSED" "$SLOG"; then
    echo "[PASS]  ${TB_NAME} — ALL TESTS PASSED"
    exit 0
else
    echo "[FAIL]  ${TB_NAME} — simulation failed (simv exit=$SIM_EXIT)"
    exit 1
fi
