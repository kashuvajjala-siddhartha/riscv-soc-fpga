
`timescale 1ns/1ps

module uart_rx #(
  parameter integer CLKS_PER_BIT = 16
)(
  input  logic       clk,
  input  logic       rst_n,
  input  logic       rx,
  output logic [7:0] byte_data,
  output logic       byte_valid
);

  logic [7:0] shift_data;

  initial begin
    byte_data  = 8'h00;
    byte_valid = 1'b0;
    shift_data = 8'h00;

    forever begin
      // Detect UART start bit
      @(negedge rx);

      if (rst_n) begin
        // Sample at the middle of the start bit
        repeat (CLKS_PER_BIT/2) @(posedge clk);

        if (rx == 1'b0) begin
          // Receive eight data bits, LSB first
          for (integer i = 0; i < 8; i++) begin
            repeat (CLKS_PER_BIT) @(posedge clk);
            shift_data[i] = rx;
          end

          // Check stop bit
          repeat (CLKS_PER_BIT) @(posedge clk);

          if (rx == 1'b1) begin
            byte_data  = shift_data;
            byte_valid = 1'b1;

            @(posedge clk);
            byte_valid = 1'b0;
          end
        end
      end
    end
  end

endmodule

