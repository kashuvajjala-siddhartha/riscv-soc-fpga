+incdir+verification
+incdir+verification/interfaces
+incdir+verification/agents/axi_lite
+incdir+verification/agents/axi_read
+incdir+verification/env
+incdir+verification/sequences
+incdir+verification/tests

../CRC/rtl/crc32_pkg.sv
verification/interfaces/soc_crc_if.sv
../CRC/rtl/crc32_byte_core.sv
../CRC/rtl/crc32_axi_lite_slave.sv
../CRC/rtl/crc32_controller.sv
../CRC/rtl/crc32_axi_read_master.sv
../CRC/rtl/crc32_top.sv
verification/soc_verification_pkg.sv
verification/soc_verification_top.sv
