#!/bin/bash

set -e

echo "======================================"
echo " CRC UVM VERIFICATION"
echo "======================================"

vcs -full64 \
    -sverilog \
    -ntb_opts uvm-1.2 \
    -timescale=1ns/1ps \
    -debug_access+all \
    -f verification/filelist.f \
    -top soc_verification_top \
    -o verification/simv_crc_uvm

echo "Compilation successful."

./verification/simv_crc_uvm \
    +UVM_TESTNAME=crc_base_test \
    +UVM_VERBOSITY=UVM_MEDIUM

echo "Simulation completed."
