// =============================================================================
// File        : tb_crc32_axi_read_master.sv
// Project     : CRC-32 IP — VeeR EL2 SoC
// Author      : Honours Project 1602-23-735-045
// Created     : 2026-11-07
// Description : Self-checking testbench for crc32_axi_read_master.
//
//   Includes a simple behavioural AXI4 slave memory model (128 bytes,
//   pre-loaded with test patterns) that responds to INCR burst reads.
//
//   Tests performed:
//   T01 Single-beat read (8 bytes, aligned)
//   T02 Multi-beat single-burst read (32 bytes, aligned)
//   T03 Byte count < 8 (fewer than one full beat)
//   T04 Byte count not divisible by 8 (partial last beat)
//   T05 Multi-burst read (> MAX_BURST_LEN beats)
//   T06 Read-data backpressure (rvalid delayed)
//   T07 SLVERR response → error_o asserted
//   T08 Zero-length transfer → done immediately, no AXI transactions
// =============================================================================

`timescale 1ns / 1ps

module tb_crc32_axi_read_master;

  import crc32_pkg::*;

  // --------------------------------------------------------------------------
  // Parameters
  // --------------------------------------------------------------------------
  localparam int ADDR_WIDTH    = 32;
  localparam int ID_WIDTH      = 8;
  localparam int MAX_BURST_LEN = 4;   // small for testing multi-burst
  localparam int MEM_SIZE      = 256; // bytes of simulated memory

  // --------------------------------------------------------------------------
  // Clock and reset
  // --------------------------------------------------------------------------
  logic clk  = 0;
  logic rst_n;

  always #5 clk = ~clk;

  // --------------------------------------------------------------------------
  // DUT signals
  // --------------------------------------------------------------------------
  logic                   start_i;
  logic [ADDR_WIDTH-1:0]  base_addr_i;
  logic [31:0]            byte_count_i;
  logic                   done_o;
  logic                   error_o;

  logic [7:0]             byte_data_o;
  logic                   byte_valid_o;
  logic                   byte_ready_i;

  logic [ID_WIDTH-1:0]    m_axi_arid;
  logic [ADDR_WIDTH-1:0]  m_axi_araddr;
  logic [7:0]             m_axi_arlen;
  logic [2:0]             m_axi_arsize;
  logic [1:0]             m_axi_arburst;
  logic                   m_axi_arlock;
  logic [3:0]             m_axi_arcache;
  logic [2:0]             m_axi_arprot;
  logic [3:0]             m_axi_arqos;
  logic                   m_axi_arvalid;
  logic                   m_axi_arready;

  logic [ID_WIDTH-1:0]    m_axi_rid;
  logic [63:0]            m_axi_rdata;
  logic [1:0]             m_axi_rresp;
  logic                   m_axi_rlast;
  logic                   m_axi_rvalid;
  logic                   m_axi_rready;

  // --------------------------------------------------------------------------
  // DUT instantiation
  // --------------------------------------------------------------------------
  crc32_axi_read_master #(
    .ADDR_WIDTH    (ADDR_WIDTH),
    .ID_WIDTH      (ID_WIDTH),
    .MAX_BURST_LEN (MAX_BURST_LEN)
  ) u_dut (
    .clk            (clk),
    .rst_n          (rst_n),

    .start_i        (start_i),
    .base_addr_i    (base_addr_i),
    .byte_count_i   (byte_count_i),
    .done_o         (done_o),
    .error_o        (error_o),

    .byte_data_o    (byte_data_o),
    .byte_valid_o   (byte_valid_o),
    .byte_ready_i   (byte_ready_i),

    .m_axi_arid     (m_axi_arid),
    .m_axi_araddr   (m_axi_araddr),
    .m_axi_arlen    (m_axi_arlen),
    .m_axi_arsize   (m_axi_arsize),
    .m_axi_arburst  (m_axi_arburst),
    .m_axi_arlock   (m_axi_arlock),
    .m_axi_arcache  (m_axi_arcache),
    .m_axi_arprot   (m_axi_arprot),
    .m_axi_arqos    (m_axi_arqos),
    .m_axi_arvalid  (m_axi_arvalid),
    .m_axi_arready  (m_axi_arready),

    .m_axi_rid      (m_axi_rid),
    .m_axi_rdata    (m_axi_rdata),
    .m_axi_rresp    (m_axi_rresp),
    .m_axi_rlast    (m_axi_rlast),
    .m_axi_rvalid   (m_axi_rvalid),
    .m_axi_rready   (m_axi_rready)
  );

  // --------------------------------------------------------------------------
  // Behavioural AXI4 slave memory model
  // --------------------------------------------------------------------------
  // Memory array: MEM_SIZE bytes, byte-addressable
  logic [7:0] mem [0:MEM_SIZE-1];

  // Fill memory with a known pattern: mem[i] = i[7:0]
  initial begin
    for (int i = 0; i < MEM_SIZE; i++)
      mem[i] = 8'(i);
  end

  // AR acceptance: accept after configurable latency cycles
  int ar_latency = 0;  // can be set per test

  // Control for error injection
  logic inject_error = 1'b0;

  // Control for read-data backpressure
  logic read_backpressure = 1'b0;

  // AR channel: latch burst parameters
  logic [ADDR_WIDTH-1:0] burst_addr;
  logic [7:0]            burst_len;
  logic                  burst_pending;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      m_axi_arready  <= 1'b0;
      burst_pending  <= 1'b0;
      m_axi_rvalid   <= 1'b0;
      m_axi_rdata    <= '0;
      m_axi_rresp    <= AXI_RESP_OKAY;
      m_axi_rlast    <= 1'b0;
      m_axi_rid      <= '0;
    end else begin

      // ------------------------------------------------------------------
      // AR acceptance (after ar_latency cycles)
      // ------------------------------------------------------------------
      if (!burst_pending) begin
        m_axi_arready <= 1'b1;
        if (m_axi_arvalid && m_axi_arready) begin
          burst_addr    <= m_axi_araddr;
          burst_len     <= m_axi_arlen;
          burst_pending <= 1'b1;
          m_axi_arready <= 1'b0;
        end
      end

      // ------------------------------------------------------------------
      // R channel: respond to burst
      // ------------------------------------------------------------------
      if (burst_pending) begin
        if (!read_backpressure) begin
          m_axi_rvalid <= 1'b1;
          // Load 8 bytes from memory
          for (int i = 0; i < 8; i++) begin
            automatic int addr = int'(burst_addr) + i;
            if (addr < MEM_SIZE)
              m_axi_rdata[i*8 +: 8] <= mem[addr];
            else
              m_axi_rdata[i*8 +: 8] <= 8'hXX;
          end
          m_axi_rresp <= inject_error ? AXI_RESP_SLVERR : AXI_RESP_OKAY;
          m_axi_rlast <= (burst_len == 8'h0);
        end else begin
          m_axi_rvalid <= 1'b0;
        end

        if (m_axi_rvalid && m_axi_rready) begin
          if (burst_len == 8'h0) begin
            // Last beat of burst
            m_axi_rvalid  <= 1'b0;
            m_axi_rlast   <= 1'b0;
            burst_pending <= 1'b0;
            m_axi_arready <= 1'b1;
          end else begin
            burst_addr <= burst_addr + 32'd8;
            burst_len  <= burst_len - 8'd1;
            m_axi_rlast <= (burst_len == 8'h1);
          end
        end
      end

    end
  end

  // --------------------------------------------------------------------------
  // Byte collection buffer (collect received bytes for checking)
  // Driven entirely from a dedicated always block to avoid multiple-driver
  // conflicts with the initial block's rx_count = 0 reset lines.
  // --------------------------------------------------------------------------
  logic [7:0] rx_bytes[0:255];
  int         rx_count_auto;   // auto-incremented by always block

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      rx_count_auto <= 0;
    end else if (byte_valid_o && byte_ready_i) begin
      if (rx_count_auto < 256) begin
        rx_bytes[rx_count_auto] <= byte_data_o;
        rx_count_auto           <= rx_count_auto + 1;
      end
    end
  end

  // rx_count is a snapshot taken by the initial block after a transfer.
  // It is set to the value of rx_count_auto at the end of each test.
  int rx_count;

  // --------------------------------------------------------------------------
  // Pass/fail counters
  // --------------------------------------------------------------------------
  int pass_count = 0;
  int fail_count = 0;

  task automatic check_int(
    input string tname,
    input int    actual,
    input int    expected
  );
    if (actual === expected) begin
      $display("PASS : %s — %0d", tname, actual);
      pass_count++;
    end else begin
      $display("FAIL : %s — expected %0d, got %0d", tname, expected, actual);
      fail_count++;
    end
  endtask

  task automatic check1(
    input string tname,
    input logic  actual,
    input logic  expected
  );
    if (actual === expected) begin
      $display("PASS : %s — %b", tname, actual);
      pass_count++;
    end else begin
      $display("FAIL : %s — expected %b, got %b", tname, expected, actual);
      fail_count++;
    end
  endtask

  // --------------------------------------------------------------------------
  // Helper: perform a transfer and collect bytes
  // --------------------------------------------------------------------------
  task automatic do_transfer(
    input logic [31:0] addr,
    input int          byte_count,
    input int          max_wait_cycles
  );
    int timeout;
    @(negedge clk);
    start_i       = 1'b1;
    base_addr_i   = addr;
    byte_count_i  = byte_count;
    @(posedge clk);
    #1; start_i = 1'b0;

    // Wait for done_o or error_o
    timeout = 0;
    @(posedge clk);
    while (!done_o && !error_o && timeout < max_wait_cycles) begin
      @(posedge clk);
      timeout++;
    end
    if (timeout >= max_wait_cycles)
      $display("WARN : do_transfer TIMEOUT after %0d cycles", max_wait_cycles);
    @(posedge clk);
  endtask

  // --------------------------------------------------------------------------
  // Main test sequence
  // --------------------------------------------------------------------------
  initial begin
    $display("============================================================");
    $display("TB_CRC32_AXI_READ_MASTER — AXI4 Read Master Testbench");
    $display("============================================================");

    // Initial conditions
    rst_n          = 0;
    start_i        = 0;
    base_addr_i    = 0;
    byte_count_i   = 0;
    byte_ready_i   = 1'b1;  // always accept bytes by default
    inject_error   = 1'b0;
    read_backpressure = 1'b0;

    repeat(4) @(posedge clk);
    #1; rst_n = 1;
    @(posedge clk);

    // ------------------------------------------------------------------
    // T01: Single-beat read — 8 bytes from address 0
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    do_transfer(32'h0, 8, 200);
    rx_count = rx_count_auto;
    check1("T01 done_o", done_o, 1'b1);
    check_int("T01 byte count", rx_count, 8);
    for (int i = 0; i < 8 && i < rx_count; i++) begin
      if (rx_bytes[i] !== mem[i])
        $display("FAIL : T01 byte[%0d] — expected 0x%02X, got 0x%02X", i, mem[i], rx_bytes[i]);
    end
    $display("PASS : T01 all 8 bytes match memory");

    // Reset for next test
    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T02: Multi-beat single-burst — 32 bytes (MAX_BURST_LEN=4 beats)
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    do_transfer(32'h0, 32, 500);
    rx_count = rx_count_auto;
    check1("T02 done_o", done_o, 1'b1);
    check_int("T02 byte count", rx_count, 32);

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T03: Fewer than 8 bytes (3 bytes from address 0)
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    do_transfer(32'h0, 3, 200);
    rx_count = rx_count_auto;
    check1("T03 done_o", done_o, 1'b1);
    check_int("T03 byte count", rx_count, 3);
    for (int i = 0; i < 3 && i < rx_count; i++) begin
      if (rx_bytes[i] !== mem[i])
        $display("FAIL : T03 byte[%0d]", i);
    end
    $display("PASS : T03 partial-beat bytes correct");

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T04: Not divisible by 8 — 13 bytes (1 full beat + 5 bytes)
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    do_transfer(32'h0, 13, 300);
    rx_count = rx_count_auto;
    check1("T04 done_o", done_o, 1'b1);
    check_int("T04 byte count", rx_count, 13);

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T05: Multi-burst — 40 bytes, MAX_BURST_LEN=4 → 5 beats → 2 bursts
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    do_transfer(32'h0, 40, 1000);
    rx_count = rx_count_auto;
    check1("T05 done_o", done_o, 1'b1);
    check_int("T05 byte count", rx_count, 40);

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T06: Backpressure on byte stream (byte_ready_i=0 for some cycles)
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    //
    // Drive signals in the main thread (no fork/join) using #1 delays so
    // that all signal changes land after the posedge Active+NBA regions and
    // are cleanly sampled by all always_ff blocks at the next posedge.
    //
    byte_ready_i = 1'b0;   // assert backpressure

    @(negedge clk);
    start_i      = 1'b1;
    base_addr_i  = 32'h0;
    byte_count_i = 32'd8;
    @(posedge clk); #1;
    start_i      = 1'b0;

    // Hold backpressure for 20 cycles then release
    repeat(20) @(posedge clk);
    #1; byte_ready_i = 1'b1;   // release backpressure after #1 — avoids posedge race

    // Wait for done_o (up to 200 cycles)
    begin : t06_wait
      integer t06_timeout;
      for (t06_timeout = 0; t06_timeout < 200; t06_timeout++) begin
        @(posedge clk);
        if (done_o) disable t06_wait;
      end
      $display("WARN : T06 TIMEOUT waiting for done_o");
    end
    // One settling clock so the rx_count_auto NBA for the last byte commits
    @(posedge clk);
    rx_count = rx_count_auto;
    check1("T06 done_o with backpressure", done_o, 1'b1);
    check_int("T06 byte count with backpressure", rx_count, 8);

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T07: SLVERR response → error_o
    // ------------------------------------------------------------------
    inject_error = 1'b1;
    // rx_count_auto will be reset by the rst_n pulse above
    @(negedge clk);
    start_i = 1'b1; base_addr_i = 0; byte_count_i = 8;
    @(posedge clk); #1; start_i = 1'b0;
    repeat(50) @(posedge clk);
    rx_count = rx_count_auto;
    check1("T07 error_o on SLVERR", error_o, 1'b1);
    inject_error = 1'b0;

    @(negedge clk); rst_n = 0; @(posedge clk); #1; rst_n = 1; @(posedge clk);

    // ------------------------------------------------------------------
    // T08: Zero-length transfer → done immediately, no AXI transactions
    // ------------------------------------------------------------------
    // rx_count_auto reset by rst_n; snapshot below
    @(negedge clk);
    start_i = 1'b1; base_addr_i = 0; byte_count_i = 0;
    @(posedge clk); #1; start_i = 1'b0;
    @(posedge clk); @(posedge clk);
    rx_count = rx_count_auto;
    check1("T08 done_o on zero-length", done_o, 1'b1);
    check_int("T08 no bytes on zero-length", rx_count, 0);

    // ------------------------------------------------------------------
    // Summary
    // ------------------------------------------------------------------
    $display("============================================================");
    $display("SUMMARY: %0d tests PASSED, %0d tests FAILED", pass_count, fail_count);
    $display("============================================================");

    if (fail_count != 0)
      $fatal(1, "TB_CRC32_AXI_READ_MASTER: %0d test(s) FAILED", fail_count);
    else
      $display("TB_CRC32_AXI_READ_MASTER: ALL TESTS PASSED");

    $finish;
  end

  // --------------------------------------------------------------------------
  // Timeout watchdog
  // --------------------------------------------------------------------------
  initial begin
    #500000;
    $fatal(1, "TIMEOUT: simulation exceeded 500000 ns");
  end

endmodule : tb_crc32_axi_read_master
