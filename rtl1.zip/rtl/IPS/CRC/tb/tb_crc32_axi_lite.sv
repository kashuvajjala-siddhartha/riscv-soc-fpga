// =============================================================================
// File        : tb_crc32_axi_lite.sv
// Project     : CRC-32 IP — VeeR EL2 SoC
// Author      : Honours Project 1602-23-735-045
// Created     : 2026-11-07
// Description : Self-checking testbench for crc32_axi_lite_slave.
//
//   The AXI-Lite slave is driven by a bus functional model (BFM) that
//   generates AXI4-Lite write and read transactions.
//
//   Tests performed:
//   T01 Write CONTROL  (AW before W)
//   T02 Write SRC_ADDR_LO (W before AW)
//   T03 Write SRC_ADDR_HI
//   T04 Write LENGTH
//   T05 Write EXPECTED_CRC
//   T06 Write IRQ_ENABLE
//   T07 Read back all written registers
//   T08 Write with byte strobes (partial write)
//   T09 Write to read-only STATUS register — verify SLVERR
//   T10 Write to invalid address — verify SLVERR
//   T11 Read from invalid address — verify SLVERR
//   T12 Write START bit in CONTROL — verify reg_start_o pulse
//   T13 Write RESET bit in CONTROL — verify reg_sw_reset_o pulse
//   T14 Read COMPUTED_CRC from mock controller input
//   T15 Read STATUS from mock controller input
//   T16 IRQ_STATUS W1C behaviour
//   T17 Back-pressure on B channel
//   T18 Back-pressure on R channel
// =============================================================================

`timescale 1ns / 1ps

module tb_crc32_axi_lite;

  import crc32_pkg::*;

  // --------------------------------------------------------------------------
  // Clock and reset
  // --------------------------------------------------------------------------
  logic clk  = 0;
  logic rst_n;

  always #5 clk = ~clk;

  // --------------------------------------------------------------------------
  // AXI4-Lite signals
  // --------------------------------------------------------------------------
  logic [31:0] s_axi_awaddr;
  logic [2:0]  s_axi_awprot;
  logic        s_axi_awvalid;
  logic        s_axi_awready;

  logic [31:0] s_axi_wdata;
  logic [3:0]  s_axi_wstrb;
  logic        s_axi_wvalid;
  logic        s_axi_wready;

  logic [1:0]  s_axi_bresp;
  logic        s_axi_bvalid;
  logic        s_axi_bready;

  logic [31:0] s_axi_araddr;
  logic [2:0]  s_axi_arprot;
  logic        s_axi_arvalid;
  logic        s_axi_arready;

  logic [31:0] s_axi_rdata;
  logic [1:0]  s_axi_rresp;
  logic        s_axi_rvalid;
  logic        s_axi_rready;

  // --------------------------------------------------------------------------
  // Controller mock interface
  // --------------------------------------------------------------------------
  logic        reg_start_o;
  logic        reg_sw_reset_o;
  logic        reg_ie_o;
  logic [31:0] reg_src_addr_o;
  logic [31:0] reg_src_addr_hi_o;
  logic [31:0] reg_length_o;
  logic [31:0] reg_expected_o;
  logic        reg_irq_clear_o;

  // Mock controller → slave inputs
  logic [4:0]  mock_status     = 5'b00100;   // PASS=1
  logic [31:0] mock_computed   = 32'hCBF43926;
  logic        mock_irq_status = 1'b0;

  // --------------------------------------------------------------------------
  // DUT instantiation
  // --------------------------------------------------------------------------
  crc32_axi_lite_slave #(
    .ADDR_WIDTH(32)
  ) u_dut (
    .clk              (clk),
    .rst_n            (rst_n),

    .s_axi_awaddr     (s_axi_awaddr),
    .s_axi_awprot     (s_axi_awprot),
    .s_axi_awvalid    (s_axi_awvalid),
    .s_axi_awready    (s_axi_awready),

    .s_axi_wdata      (s_axi_wdata),
    .s_axi_wstrb      (s_axi_wstrb),
    .s_axi_wvalid     (s_axi_wvalid),
    .s_axi_wready     (s_axi_wready),

    .s_axi_bresp      (s_axi_bresp),
    .s_axi_bvalid     (s_axi_bvalid),
    .s_axi_bready     (s_axi_bready),

    .s_axi_araddr     (s_axi_araddr),
    .s_axi_arprot     (s_axi_arprot),
    .s_axi_arvalid    (s_axi_arvalid),
    .s_axi_arready    (s_axi_arready),

    .s_axi_rdata      (s_axi_rdata),
    .s_axi_rresp      (s_axi_rresp),
    .s_axi_rvalid     (s_axi_rvalid),
    .s_axi_rready     (s_axi_rready),

    .reg_start_o      (reg_start_o),
    .reg_sw_reset_o   (reg_sw_reset_o),
    .reg_ie_o         (reg_ie_o),
    .reg_src_addr_o   (reg_src_addr_o),
    .reg_src_addr_hi_o(reg_src_addr_hi_o),
    .reg_length_o     (reg_length_o),
    .reg_expected_o   (reg_expected_o),
    .reg_irq_clear_o  (reg_irq_clear_o),

    .reg_status_i     (mock_status),
    .reg_computed_i   (mock_computed),
    .reg_irq_status_i (mock_irq_status)
  );

  // --------------------------------------------------------------------------
  // Pass/fail counters
  // --------------------------------------------------------------------------
  int pass_count = 0;
  int fail_count = 0;

  task automatic check(
    input string      tname,
    input logic [31:0] actual,
    input logic [31:0] expected
  );
    if (actual === expected) begin
      $display("PASS : %s — 0x%08X", tname, actual);
      pass_count++;
    end else begin
      $display("FAIL : %s — expected 0x%08X, got 0x%08X", tname, expected, actual);
      fail_count++;
    end
  endtask

  task automatic check1(
    input string tname,
    input logic  actual,
    input logic  expected
  );
    if (actual === expected) begin
      $display("PASS : %s — %b", tname, actual);
      pass_count++;
    end else begin
      $display("FAIL : %s — expected %b, got %b", tname, expected, actual);
      fail_count++;
    end
  endtask

  // --------------------------------------------------------------------------
  // AXI BFM tasks
  // --------------------------------------------------------------------------
  task automatic reset_bus();
    s_axi_awvalid = 0; s_axi_awaddr = 0; s_axi_awprot = 0;
    s_axi_wvalid  = 0; s_axi_wdata  = 0; s_axi_wstrb  = 0;
    s_axi_bready  = 1;  // always accept B response
    s_axi_arvalid = 0; s_axi_araddr = 0; s_axi_arprot = 0;
    s_axi_rready  = 1;  // always accept R response by default
  endtask

  // Write: AW then W (sequential)
  task automatic axi_write_aw_first(
    input logic [31:0] addr,
    input logic [31:0] data,
    input logic [3:0]  strb,
    output logic [1:0] bresp_out
  );
    // Send AW
    @(negedge clk);
    s_axi_awvalid = 1'b1;
    s_axi_awaddr  = addr;
    @(posedge clk);
    while (!s_axi_awready) @(posedge clk);
    @(negedge clk); s_axi_awvalid = 1'b0;

    // Wait a cycle then send W
    @(posedge clk);
    @(negedge clk);
    s_axi_wvalid = 1'b1;
    s_axi_wdata  = data;
    s_axi_wstrb  = strb;
    @(posedge clk);
    while (!s_axi_wready) @(posedge clk);
    @(negedge clk); s_axi_wvalid = 1'b0;

    // Wait for B response
    @(posedge clk);
    while (!s_axi_bvalid) @(posedge clk);
    bresp_out = s_axi_bresp;
    @(posedge clk);
  endtask

  // Write: W then AW (reversed)
  task automatic axi_write_w_first(
    input logic [31:0] addr,
    input logic [31:0] data,
    input logic [3:0]  strb,
    output logic [1:0] bresp_out
  );
    // Send W first
    @(negedge clk);
    s_axi_wvalid = 1'b1;
    s_axi_wdata  = data;
    s_axi_wstrb  = strb;
    @(posedge clk);
    while (!s_axi_wready) @(posedge clk);
    @(negedge clk); s_axi_wvalid = 1'b0;

    // Wait a cycle then send AW
    @(posedge clk);
    @(negedge clk);
    s_axi_awvalid = 1'b1;
    s_axi_awaddr  = addr;
    @(posedge clk);
    while (!s_axi_awready) @(posedge clk);
    @(negedge clk); s_axi_awvalid = 1'b0;

    // Wait for B
    @(posedge clk);
    while (!s_axi_bvalid) @(posedge clk);
    bresp_out = s_axi_bresp;
    @(posedge clk);
  endtask

  // Write: AW and W simultaneous
  task automatic axi_write_simultaneous(
    input logic [31:0] addr,
    input logic [31:0] data,
    input logic [3:0]  strb,
    output logic [1:0] bresp_out
  );
    @(negedge clk);
    s_axi_awvalid = 1'b1; s_axi_awaddr = addr;
    s_axi_wvalid  = 1'b1; s_axi_wdata  = data; s_axi_wstrb = strb;
    @(posedge clk);
    while (!s_axi_awready || !s_axi_wready) @(posedge clk);
    @(negedge clk);
    s_axi_awvalid = 1'b0;
    s_axi_wvalid  = 1'b0;
    @(posedge clk);
    while (!s_axi_bvalid) @(posedge clk);
    bresp_out = s_axi_bresp;
    @(posedge clk);
  endtask

  // Read transaction
  task automatic axi_read(
    input  logic [31:0] addr,
    output logic [31:0] data_out,
    output logic [1:0]  rresp_out
  );
    @(negedge clk);
    s_axi_arvalid = 1'b1;
    s_axi_araddr  = addr;
    @(posedge clk);
    while (!s_axi_arready) @(posedge clk);
    @(negedge clk); s_axi_arvalid = 1'b0;

    // Wait for R response
    @(posedge clk);
    while (!s_axi_rvalid) @(posedge clk);
    data_out  = s_axi_rdata;
    rresp_out = s_axi_rresp;
    @(posedge clk);
  endtask

  // --------------------------------------------------------------------------
  // Test variables
  // --------------------------------------------------------------------------
  logic [1:0]  bresp;
  logic [31:0] rdata;
  logic [1:0]  rresp;
  logic        start_seen;
  logic        reset_seen;

  // --------------------------------------------------------------------------
  // Main test body
  // --------------------------------------------------------------------------
  initial begin
    $display("============================================================");
    $display("TB_CRC32_AXI_LITE — AXI4-Lite Slave Testbench");
    $display("============================================================");

    rst_n = 0;
    reset_bus();
    repeat(4) @(posedge clk);
    #1; rst_n = 1;
    @(posedge clk);

    // ------------------------------------------------------------------
    // T01: Write CONTROL (AW before W)
    // ------------------------------------------------------------------
    axi_write_aw_first(32'h00, 32'h00000002, 4'hF, bresp);
    check("T01 CONTROL write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T02: Write SRC_ADDR_LO (W before AW)
    // ------------------------------------------------------------------
    axi_write_w_first(32'h08, 32'hDEAD_BEEF, 4'hF, bresp);
    check("T02 SRC_ADDR_LO write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T03: Write SRC_ADDR_HI
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h0C, 32'h0000_1234, 4'hF, bresp);
    check("T03 SRC_ADDR_HI write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T04: Write LENGTH
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h10, 32'h0000_0009, 4'hF, bresp);
    check("T04 LENGTH write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T05: Write EXPECTED_CRC
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h14, 32'hCBF43926, 4'hF, bresp);
    check("T05 EXPECTED_CRC write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T06: Write IRQ_ENABLE
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h1C, 32'h0000_0001, 4'hF, bresp);
    check("T06 IRQ_ENABLE write bresp", {30'b0, bresp}, 32'h0);

    // ------------------------------------------------------------------
    // T07: Read back all written registers
    // ------------------------------------------------------------------
    axi_read(32'h08, rdata, rresp);
    check("T07a SRC_ADDR_LO readback", rdata, 32'hDEAD_BEEF);
    check("T07a SRC_ADDR_LO rresp", {30'b0, rresp}, 32'h0);

    axi_read(32'h0C, rdata, rresp);
    check("T07b SRC_ADDR_HI readback", rdata, 32'h0000_1234);

    axi_read(32'h10, rdata, rresp);
    check("T07c LENGTH readback", rdata, 32'h0000_0009);

    axi_read(32'h14, rdata, rresp);
    check("T07d EXPECTED_CRC readback", rdata, 32'hCBF43926);

    axi_read(32'h1C, rdata, rresp);
    check("T07e IRQ_ENABLE readback", rdata[0:0], 32'h1);

    // ------------------------------------------------------------------
    // T08: Byte-strobe write (only bytes 0 and 1)
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h08, 32'hXXXX_CAFE, 4'h3, bresp); // strb=0011
    axi_read(32'h08, rdata, rresp);
    // Lower 2 bytes should be 0xCAFE, upper 2 should be 0xDEAD
    check("T08 Byte-strobe partial write", rdata, 32'hDEAD_CAFE);

    // ------------------------------------------------------------------
    // T09: Write to read-only STATUS register → SLVERR
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h04, 32'hFFFFFFFF, 4'hF, bresp);
    check("T09 STATUS write bresp == SLVERR", {30'b0, bresp}, 32'h2);

    // ------------------------------------------------------------------
    // T10: Write to invalid address → SLVERR
    // ------------------------------------------------------------------
    axi_write_simultaneous(32'h50, 32'h12345678, 4'hF, bresp);
    check("T10 Invalid addr write bresp == SLVERR", {30'b0, bresp}, 32'h2);

    // ------------------------------------------------------------------
    // T11: Read from invalid address → SLVERR
    // ------------------------------------------------------------------
    axi_read(32'h50, rdata, rresp);
    check("T11 Invalid addr read rresp == SLVERR", {30'b0, rresp}, 32'h2);

    // ------------------------------------------------------------------
    // T12: Write START bit → reg_start_o pulse
    // ------------------------------------------------------------------
    start_seen = 1'b0;
    fork
      begin
        // Monitor reg_start_o for one-cycle pulse
        @(posedge clk);
        repeat(10) begin
          @(posedge clk);
          if (reg_start_o) start_seen = 1'b1;
        end
      end
      begin
        axi_write_simultaneous(32'h00, 32'h0000_0001, 4'hF, bresp);
      end
    join
    check1("T12 START pulse seen", start_seen, 1'b1);

    // ------------------------------------------------------------------
    // T13: Write RESET bit → reg_sw_reset_o pulse
    // ------------------------------------------------------------------
    reset_seen = 1'b0;
    fork
      begin
        @(posedge clk);
        repeat(10) begin
          @(posedge clk);
          if (reg_sw_reset_o) reset_seen = 1'b1;
        end
      end
      begin
        axi_write_simultaneous(32'h00, 32'h0000_0004, 4'hF, bresp);
      end
    join
    check1("T13 SW_RESET pulse seen", reset_seen, 1'b1);

    // ------------------------------------------------------------------
    // T14: Read COMPUTED_CRC (from mock controller)
    // ------------------------------------------------------------------
    axi_read(32'h18, rdata, rresp);
    check("T14 COMPUTED_CRC read", rdata, 32'hCBF43926);

    // ------------------------------------------------------------------
    // T15: Read STATUS (from mock controller: PASS=1)
    // ------------------------------------------------------------------
    axi_read(32'h04, rdata, rresp);
    check("T15 STATUS read (PASS bit)", rdata[2], 32'h1);

    // ------------------------------------------------------------------
    // T16: IRQ_STATUS W1C
    // ------------------------------------------------------------------
    mock_irq_status = 1'b1;
    @(posedge clk);
    axi_read(32'h20, rdata, rresp);
    check("T16a IRQ_STATUS read == 1", rdata[0], 32'h1);
    // Write 1 to clear — monitor the one-cycle pulse with a fork
    // (reg_irq_clear_o is a registered one-cycle pulse; sample during write)
    begin
      logic irq_clear_seen;
      irq_clear_seen = 1'b0;
      fork
        begin
          // Monitor for pulse during and just after the write transaction
          repeat(15) begin
            @(posedge clk);
            if (reg_irq_clear_o) irq_clear_seen = 1'b1;
          end
        end
        begin
          axi_write_simultaneous(32'h20, 32'h0000_0001, 4'hF, bresp);
        end
      join
      check1("T16b IRQ clear pulse", irq_clear_seen, 1'b1);
    end

    // ------------------------------------------------------------------
    // T17: B-channel backpressure (bready=0, hold off)
    // ------------------------------------------------------------------
    s_axi_bready = 1'b0;  // disable B acceptance
    @(negedge clk);
    s_axi_awvalid = 1'b1; s_axi_awaddr = 32'h10;
    s_axi_wvalid  = 1'b1; s_axi_wdata  = 32'h0000_0010; s_axi_wstrb = 4'hF;
    @(posedge clk);
    while (!s_axi_awready || !s_axi_wready) @(posedge clk);
    @(negedge clk); s_axi_awvalid = 1'b0; s_axi_wvalid = 1'b0;
    // Wait several cycles without accepting B
    repeat(5) @(posedge clk);
    // bvalid should remain asserted while bready=0
    check1("T17 B backpressure bvalid", s_axi_bvalid, 1'b1);
    // Now accept
    @(negedge clk); s_axi_bready = 1'b1;
    @(posedge clk);
    @(posedge clk);
    check1("T17 B backpressure bvalid after accept", s_axi_bvalid, 1'b0);

    // ------------------------------------------------------------------
    // T18: R-channel backpressure (rready=0)
    // ------------------------------------------------------------------
    s_axi_rready = 1'b0;
    @(negedge clk);
    s_axi_arvalid = 1'b1; s_axi_araddr = 32'h10;
    @(posedge clk);
    while (!s_axi_arready) @(posedge clk);
    @(negedge clk); s_axi_arvalid = 1'b0;
    // Wait without accepting R
    repeat(5) @(posedge clk);
    check1("T18 R backpressure rvalid", s_axi_rvalid, 1'b1);
    // Accept
    @(negedge clk); s_axi_rready = 1'b1;
    @(posedge clk);
    @(posedge clk);
    check1("T18 R backpressure rvalid after accept", s_axi_rvalid, 1'b0);

    // ------------------------------------------------------------------
    // Summary
    // ------------------------------------------------------------------
    $display("============================================================");
    $display("SUMMARY: %0d tests PASSED, %0d tests FAILED", pass_count, fail_count);
    $display("============================================================");

    if (fail_count != 0)
      $fatal(1, "TB_CRC32_AXI_LITE: %0d test(s) FAILED", fail_count);
    else
      $display("TB_CRC32_AXI_LITE: ALL TESTS PASSED");

    $finish;
  end

  // --------------------------------------------------------------------------
  // Timeout watchdog
  // --------------------------------------------------------------------------
  initial begin
    #200000;
    $fatal(1, "TIMEOUT: simulation exceeded 200000 ns");
  end

endmodule : tb_crc32_axi_lite
