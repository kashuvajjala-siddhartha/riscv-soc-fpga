#!/usr/bin/env bash
# =============================================================================
# run.sh — CRC-32 IP VCS Simulation Script
# Project : CRC-32 IP — VeeR EL2 SoC
# Author  : Honours Project 1602-23-735-045
# =============================================================================
#
# Compiles and runs all four CRC-32 IP testbenches using Synopsys VCS.
# Returns exit code 0 if all pass, non-zero if any fail or error.
#
# Usage:
#   ./run.sh               — run all testbenches
#   ./run.sh core          — run only tb_crc32_core
#   ./run.sh axi_lite      — run only tb_crc32_axi_lite
#   ./run.sh axi_rm        — run only tb_crc32_axi_read_master
#   ./run.sh soc           — run only tb_crc32_soc
#   ./run.sh clean         — remove build artefacts
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
VCS_HOME=/home/student/snps_tools_target/vcs/U-2023.03
export VCS_HOME
export PATH=$VCS_HOME/linux64/bin:$VCS_HOME/bin:$PATH
export LD_LIBRARY_PATH=/usr/lib64:$VCS_HOME/linux64/lib:${LD_LIBRARY_PATH:-}
export LM_LICENSE_FILE=27020@cadence

VCS=$VCS_HOME/bin/vcs
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRC_ROOT="$(dirname "$SCRIPT_DIR")"
RTL_DIR="$CRC_ROOT/rtl"
TB_DIR="$CRC_ROOT/tb"
WORK_DIR="$SCRIPT_DIR/work"

VCS_COMMON="-full64 -sverilog +v2k -timescale=1ns/1ps -debug_access+all +warn=all"

RTL_FILES=(
    "$RTL_DIR/crc32_pkg.sv"
    "$RTL_DIR/crc32_byte_core.sv"
    "$RTL_DIR/crc32_axi_lite_slave.sv"
    "$RTL_DIR/crc32_controller.sv"
    "$RTL_DIR/crc32_axi_read_master.sv"
    "$RTL_DIR/crc32_top.sv"
)

# ---------------------------------------------------------------------------
# Counters
# ---------------------------------------------------------------------------
PASS=0
FAIL=0

# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------
log_info()  { echo "[INFO]  $*"; }
log_pass()  { echo "[PASS]  $*"; }
log_fail()  { echo "[FAIL]  $*"; }
log_sep()   { echo "============================================================"; }

compile_and_run() {
    local tb_name="$1"
    local tb_file="$TB_DIR/${tb_name}.sv"
    local simv="$WORK_DIR/simv_${tb_name}"
    local clog="$WORK_DIR/compile_${tb_name}.log"
    local slog="$WORK_DIR/sim_${tb_name}.log"

    log_sep
    log_info "Compiling $tb_name ..."

    mkdir -p "$WORK_DIR"

    if ! "$VCS" $VCS_COMMON \
            -top "$tb_name" \
            -o "$simv" \
            -l "$clog" \
            "${RTL_FILES[@]}" "$tb_file" 2>&1 | tee "$clog"; then
        log_fail "COMPILE FAILED: $tb_name (see $clog)"
        FAIL=$((FAIL + 1))
        return 1
    fi

    log_info "Running $tb_name ..."

    # Run simulation and capture exit code explicitly.
    # -no_save avoids ASLR re-exec overhead.
    set +e
    "$simv" -no_save 2>&1 | tee "$slog"
    local sim_exit=${PIPESTATUS[0]}
    set -e

    # Determine pass/fail:
    #   PASS: simv exits 0 AND the testbench printed "ALL TESTS PASSED"
    #   FAIL: simv exits non-zero (caught $fatal) OR success marker absent
    #
    # We do NOT grep for the word "FAIL" because test labels such as
    # "T02 STATUS.FAIL" and "check vector FAIL" legitimately contain it.
    # $fatal produces "Fatal:" in the log; simv exits non-zero on $fatal.
    if [ "$sim_exit" -eq 0 ] && grep -q "ALL TESTS PASSED" "$slog"; then
        log_pass "$tb_name — ALL TESTS PASSED"
        PASS=$((PASS + 1))
        return 0
    else
        log_fail "SIMULATION FAILED: $tb_name (simv exit=$sim_exit, see $slog)"
        FAIL=$((FAIL + 1))
        return 1
    fi
}

# ---------------------------------------------------------------------------
# Argument handling
# ---------------------------------------------------------------------------
TARGET="${1:-all}"

case "$TARGET" in
    core)
        compile_and_run "tb_crc32_core" || true
        ;;
    axi_lite)
        compile_and_run "tb_crc32_axi_lite" || true
        ;;
    axi_rm)
        compile_and_run "tb_crc32_axi_read_master" || true
        ;;
    soc)
        compile_and_run "tb_crc32_soc" || true
        ;;
    clean)
        log_info "Cleaning build artefacts ..."
        rm -rf "$WORK_DIR" csrc *.daidir *.log *.vcd *.fsdb ucli.key
        log_info "Clean complete"
        exit 0
        ;;
    all)
        compile_and_run "tb_crc32_core"              || true
        compile_and_run "tb_crc32_axi_lite"          || true
        compile_and_run "tb_crc32_axi_read_master"   || true
        compile_and_run "tb_crc32_soc"               || true
        ;;
    *)
        echo "Usage: $0 [core|axi_lite|axi_rm|soc|all|clean]"
        exit 1
        ;;
esac

# ---------------------------------------------------------------------------
# Final summary
# ---------------------------------------------------------------------------
log_sep
echo "  SIMULATION SUMMARY"
echo "  Testbenches PASSED : $PASS"
echo "  Testbenches FAILED : $FAIL"
log_sep

if [ "$FAIL" -ne 0 ]; then
    echo "OVERALL RESULT: FAILED ($FAIL testbench(es) failed)"
    exit 1
else
    echo "OVERALL RESULT: PASSED"
    exit 0
fi
